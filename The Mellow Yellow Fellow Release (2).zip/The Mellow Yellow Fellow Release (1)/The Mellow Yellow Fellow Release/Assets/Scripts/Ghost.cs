﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ghost : MonoBehaviour
{

    [SerializeField]
    Material scaredMaterial;
    Material normalMaterial;

    public Transform GhostHouse;

    UnityEngine.AI.NavMeshAgent agent;

    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        agent.destination = PickRandomPosition();
        normalMaterial = GetComponent<Renderer>().material;
    }

    Vector3 PickRandomPosition()
    {
        Vector3 destination = transform.position;
        Vector2 randomDirection = UnityEngine.Random.insideUnitCircle * 8.0f;
        destination.x += randomDirection.x;
        destination.z += randomDirection.y;

        UnityEngine.AI.NavMeshHit navHit;
        UnityEngine.AI.NavMesh.SamplePosition(destination, out navHit, 8.0f, UnityEngine.AI.NavMesh.AllAreas);

        return navHit.position;
    }

    // Update is called once per frame
    bool hiding = false;
    void Update()
    {
        if (player.PowerupActive())
        {
            //Debug.Log("Hiding  from  Player!");
            if (!hiding || agent.remainingDistance < 0.5f)
            {
                hiding = true;
                agent.destination = PickHidingPlace();
                GetComponent<Renderer>().material = scaredMaterial;
            }
        }
        else
        {
            //Debug.Log("Chasing  Player!");
            if (hiding)
            {
                GetComponent<Renderer>().material = normalMaterial;
                hiding = false;
            }

            if (agent.remainingDistance < 0.5f)
            {
                agent.destination = PickRandomPosition();
                hiding = false;
                GetComponent<Renderer>().material = normalMaterial;
            }

        }
    }

    [SerializeField]
    Fellow player;

    bool CanSeePlayer()
    {
        Vector3 rayPos = transform.position;
        Vector3 rayDir = (player.transform.position - rayPos).normalized;

        RaycastHit info;
        if (Physics.Raycast(rayPos, rayDir, out info))
        {
            if (info.transform.CompareTag("Fellow"))
            {
                return true;
            }
        }
        return false;
    }

    Vector3 PickHidingPlace()
    {
        Vector3 directionToPlayer = (player.transform.position - 
            transform.position).normalized;
        UnityEngine.AI.NavMeshHit navHit;
        UnityEngine.AI.NavMesh.SamplePosition(transform.position -
            (directionToPlayer * 8.0f), out navHit, 8.0f, UnityEngine.AI.NavMesh.AllAreas);

        return navHit.position;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Fellow"))
        {
            if (!player.PowerupActive())
            {
                //Player has powerup active if hiding is true so move the ghost to the ghost house upon collision
                transform.position = GhostHouse.position;
            }
            if (player.PowerupActive())
            {
                //Player loses a life, put the position change in this and fellow to try and stop bug of sometimes not moving
                transform.position = GhostHouse.position;
            }

        }
    }

    void OnTriggerEnter(Collider other)
    {
        //Teleport the Ghosts when in contact with the teleporter
        if (other.gameObject.CompareTag("Teleporter"))
        {
            //Teleport the ghost to the other side
            Debug.Log("Teleport Activated");

        }
    }


}
