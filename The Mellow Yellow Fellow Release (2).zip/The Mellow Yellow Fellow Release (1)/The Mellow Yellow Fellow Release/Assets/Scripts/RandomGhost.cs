﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomGhost : MonoBehaviour
{
    [SerializeField]
    Fellow player;

    [SerializeField]
    Material scaredMaterial;
    Material normalMaterial;

    UnityEngine.AI.NavMeshAgent agent;

    public Transform GhostHouse;
    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        agent.destination = PickRandomPosition();
        normalMaterial = GetComponent<Renderer>().material;

    }

    // Update is called once per frame
    void Update()
    {
        if (player.PowerupActive())
        {
            GetComponent<Renderer>().material = scaredMaterial;
        }
        else
        { 
            GetComponent<Renderer>().material = normalMaterial;
        }

        if (agent.remainingDistance < 0.5f)
        {
            agent.destination = PickRandomPosition();
         
        }     
    }


    //This Ghost just picks random positions irrelevant of the player
    Vector3 PickRandomPosition()
    {
        Vector3 destination = transform.position;
        Vector2 randomDirection = UnityEngine.Random.insideUnitCircle * 8.0f;
        destination.x += randomDirection.x;
        destination.z += randomDirection.y;

        UnityEngine.AI.NavMeshHit navHit;
        UnityEngine.AI.NavMesh.SamplePosition(destination, out navHit, 8.0f, UnityEngine.AI.NavMesh.AllAreas);

        return navHit.position;
    }

    void onCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Fellow"))
        {
            transform.position = GhostHouse.position;
        }

    }



}
