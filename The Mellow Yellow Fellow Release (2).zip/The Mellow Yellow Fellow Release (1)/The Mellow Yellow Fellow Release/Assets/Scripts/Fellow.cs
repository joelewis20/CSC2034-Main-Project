﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Fellow : MonoBehaviour
{
    public Vector3 originalPosition;
    //Text ScoreCount;
    // Start is called before the first frame update
    void Start()
    {
        originalPosition = transform.position;
       // ScoreCount = gameObject.GetComponent<Text>();
        //ScoreCount.text = "Score: " + score;
    }

    [SerializeField]
    float speed = 0.05f;

    // Update is called once per frame
    
    void Update()
    {
        //ScoreCount.text = "Score: " + score;
        powerupTime = Mathf.Max(0.0f, powerupTime - Time.deltaTime);
        /*
        
        Vector3 pos = transform.position;

        if (Input.GetKey(KeyCode.A))
        {
            pos.x -= speed;
        }

        if (Input.GetKey(KeyCode.D))
        {
            pos.x += speed;
        }

        if (Input.GetKey(KeyCode.W))
        {
            pos.z += speed;
        }

        if (Input.GetKey(KeyCode.S))
        {
            pos.z -= speed;
        }
        transform.position = pos;
 
        */
    }
    

    void FixedUpdate()
    {
        Rigidbody b = GetComponent<Rigidbody>();
        Vector3 velocity = b.velocity;

        if (Input.GetKey(KeyCode.A))
        {
            velocity.x = -speed;
        }

        if (Input.GetKey(KeyCode.D))
        {
            velocity.x = speed;
        }

        if (Input.GetKey(KeyCode.W))
        {
            velocity.z = speed;
        }

        if (Input.GetKey(KeyCode.S))
        {
            velocity.z = -speed;
        }
        b.velocity = velocity;
    }

    int score = 0;
    int pelletsEaten = 0;
    [SerializeField]
    int pointsPerPellet = 100;

    [SerializeField]
    int pointsPerGhostEat = 150;

    [SerializeField]
    int Lives = 3;

    [SerializeField]
    float powerupDuration = 10.0f; //How  long  should  powerups  last?

    float powerupTime = 0.0f;   //How  long is left on the  current  powerup?

    //Add Cooldown to teleport
    [SerializeField]
    float teleportDuration = 2.0f;

    float teleportTime = 0.0f;


    public Transform teleport1;
    public Transform teleport2;
    public Transform GhostHouse;


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pellet"))
        {
            pelletsEaten++;
            score += pointsPerPellet;
            Debug.Log("Score is " + score);
        }

        if (other.gameObject.CompareTag("Powerup"))
        {
            powerupTime = powerupDuration;
            other.gameObject.SetActive(false);
        }

        if(other.gameObject.CompareTag("Teleporter"))
        {
            //Teleport the fellow when in contact with the teleporter tagged area
            Debug.Log("Teleport Test");
            //IF using teleport 1 transport to teleport 2
            if (other.transform.position == teleport1.position)
            {
                if (!TeleportActive()) 
                {
                    transform.position = teleport2.position;
                    //Issue of instantly teleporting back
                }

            }
            //IF using teleport 2 transport to teleport 1
            if (other.transform.position == teleport2.position)
            {
                if (!TeleportActive())
                {
                    transform.position = teleport1.position;
                    //Issue of instantly teleporting back
                }

            }
        }


    }

    //Cooldwon for teleport to attempt to try and preventing teleporting straight back
    public bool TeleportActive()
    {
        return teleportTime > 0.0f;
    }

    public bool PowerupActive()
    {
        return powerupTime > 0.0f;
    }

    public int PelletsEaten()
    {
        return pelletsEaten;
    }

    public int getScore()
    {
        return score;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ghost"))
        {
            //Debug.Log("You  died!");
            if (!PowerupActive())
            {
                //If the powerup isn't active and a collision occurs the game ends (currently)
                //gameObject.SetActive(false);

                //If powerup isn't active and collision occurs remove a life
                if (Lives > 0)
                {
                    Lives = Lives - 1;
                    Debug.Log("Current Lives = " + Lives);
                    //Send the Ghosts to the Ghosts House
                    collision.transform.position = GhostHouse.position;
                    //Reset the Player to the starting position
                    transform.position = originalPosition;
                }
                if (Lives == 0)
                {
                    //Reset the Scene
                    SceneManager.LoadScene(SceneManager.GetActiveScene().name);
                    //This resets the score (may be an issue when doing user interface)
                }
               
            }

            if (PowerupActive())
            {
                collision.transform.position = GhostHouse.position;
                score += pointsPerGhostEat;
                Debug.Log("Score is " + score);
            }
            //Change this to take off a life and set active false when lives = 0
            //If lives don't = 0 teleport to the ghost house in
        }

    }




}
