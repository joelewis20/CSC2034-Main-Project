﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameScoreboard : MonoBehaviour
{
    Text ScoreCount;
    [SerializeField]
    Fellow player;

    // Start is called before the first frame update
    void Start()
    {
        ScoreCount = gameObject.GetComponent<Text>();
        ScoreCount.text = "Score: " + player.getScore();
    }

    // Update is called once per frame
    void Update()
    {
        ScoreCount.text = "Score: " + player.getScore();
    }
}
